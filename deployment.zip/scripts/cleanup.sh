#!/bin/bash
# Loescht die index.html, die den Fehler verursacht
rm -f /var/www/html/index.html 

